import java.util.*;

public class Solution {
	
	public static void main(String[] args) {
		Solution soln = new Solution();
		int[]arr = {1,2,3,4,6,7};
		System.out.println(soln.solution(arr));
	}
	
	public int solution(int[] A) {
        // write your code in Java SE 8
        int small = 1;
        int maxSize = 1000000;

        if(A.length == 0) return small;

        Arrays.sort(A);
        if(A[0] > 1) return small;
        
        for(int i = 0; i<A.length;i++){
            if(A[i] == small) small++;

        }
	return small;
    }

}
