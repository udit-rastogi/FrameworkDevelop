package seleniumAutomationPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class SearchInGoogleTest {
	UiSearchInGoogle sig = new UiSearchInGoogle();
	WebElement e = null;
	WebDriver d = null;

	@Test
	public void test() throws InterruptedException {

		d = sig.initBrowser();
		d.findElement(By.name("q")).click();
		d.findElement(By.name("q")).sendKeys("IndexOutOfBounds error");
		Thread.sleep(2000);
		sig.highlightElement(d.findElement(By.xpath("//div[@class = 'aajZCb']//ul/li[6]//div[@class='sbl1']/span")));
//		sig.retryingFindClick(By.xpath("//div[@class = 'aajZCb']//ul/li[6]//div[@class='sbl1']/span"));
//		e = d.findElement(By.xpath("//div[@class = 'aajZCb']//ul/li[6]//div[@class='sbl1']/span"));
		// e.click();

		Thread.sleep(2000);
		sig.tearDown();
	}

}
