package seleniumAutomationPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UiPage {
	@FindBy(className = "gLFyf gsfi")
	WebElement searchBox;

//	public UiPage() {
//		PageFactory()
//	}
}
