package restAPIStuff;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import apiPkg.TestBase;
import apiPkg.Utils;
import apiPkg.apiDefinitions.CreateCustomerApiDefinition;
import apiPkg.objects.CreateUserRequest;
import apiPkg.objects.CreateUserResponse;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DemoApiTest extends TestBase {
	public static Logger logger = Logger.getLogger(DemoApiTest.class);

	public DemoApiTest() {
		super();
	}

	@Test(groups = { "A", "B" })
	public void testAPI() {
		Response response = null;
		final CreateUserRequest request = CreateCustomerApiDefinition.createRequest();
		final String payload = Utils.getJsonFromObject(request);
		logger.info(" Create User Request Details: " + payload);

		response = reqGeneric().body(payload).when().post("https://gorest.co.in/public-api/users");
		logger.info(" Create User Response Details: " + response.asPrettyString());
		final CreateUserResponse createUserResponse = response.getBody().as(CreateUserResponse.class);

		Assert.assertTrue(createUserResponse.getCode() == 201,
				"Expected Code [ 202 ] matches actual [ " + createUserResponse.getCode() + " ]");

		int customerId = createUserResponse.getData().getId();
		System.out.println("Customer Id of an user is --> " + customerId);
		System.out.println("\n \n End of Test");

	}

}
