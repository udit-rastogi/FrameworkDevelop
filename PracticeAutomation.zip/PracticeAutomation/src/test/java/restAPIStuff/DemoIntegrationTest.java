package restAPIStuff;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import apiPkg.TestBase;
import apiPkg.Utils;
import apiPkg.apiDefinitions.CreateCustomerApiDefinition;
import apiPkg.objects.CreateUserRequest;
import apiPkg.objects.CreateUserResponse;
import io.restassured.response.Response;

public class DemoIntegrationTest extends TestBase {
	public static Logger logger = Logger.getLogger(TestBase.class.getName());
	Response response = null;

	public DemoIntegrationTest() {
		super();
	}

	@Test(groups = "A")
	public void createAndGetUser() {

		final CreateUserRequest request = CreateCustomerApiDefinition.createRequest();
		final String payload = Utils.getJsonFromObject(request);

		response = reqGeneric().body(payload).log().all().when().post("https://gorest.co.in/public-api/users");

		System.out.println("Create Customer Response --> \n" + response.asPrettyString());

		final CreateUserResponse createUserResponse = response.getBody().as(CreateUserResponse.class);

		Assert.assertTrue(createUserResponse.getCode() == 201,
				"Expected Code [ 200 ] matches actual [ " + createUserResponse.getCode() + " ]");

		int customerId = createUserResponse.getData().getId();
		System.out.println("Customer Id of an user is --> " + customerId);

		System.out.println("------------------------------ GET USER ----------------------------/n");

		String url = "https://gorest.co.in/public-api/users/" + customerId;

		response = reqGeneric().pathParam("id", customerId).log().all().when()
				.get("https://gorest.co.in/public-api/users/{id}");
		final CreateUserResponse getUserResponse = response.getBody().as(CreateUserResponse.class);

		System.out.println("Create Customer Response --> /n" + response.asPrettyString());

		Assert.assertTrue(getUserResponse.getCode() == 200,
				"Expected Code [ 200 ] matches actual [ " + getUserResponse.getCode() + " ]");

		Assert.assertTrue(getUserResponse.getData().getId() == customerId, "Expected Customer Id [ " + customerId
				+ " ] matches actual [ " + getUserResponse.getData().getId() + " ]");
	}
}
