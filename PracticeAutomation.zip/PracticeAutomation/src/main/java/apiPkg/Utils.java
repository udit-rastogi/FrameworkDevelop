package apiPkg;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Utils {

	public static String getJsonFromObject(Object request) {
		return getJsonFromObject(request, Include.ALWAYS);
	}

	public static String getJsonFromObject(Object request, Include includeRule) {
		ObjectMapper mapper = new ObjectMapper();
		String str = null;
		try {
			mapper.setSerializationInclusion(includeRule);
			str = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			System.out.println(e.getMessage());
		}
		return str;
	}

}
