package apiPkg.objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "code", "meta", "data" })

public class CreateUserResponse {

	@JsonProperty("code")
	private Integer code;
	@JsonProperty("meta")
	private Object meta;
	@JsonProperty("data")
	private Data data;

	@JsonProperty("code")
	public Integer getCode() {
		return code;
	}

	@JsonProperty("code")
	public void setCode(Integer code) {
		this.code = code;
	}

	@JsonProperty("meta")
	public Object getMeta() {
		return meta;
	}

	@JsonProperty("meta")
	public void setMeta(Object meta) {
		this.meta = meta;
	}

	@JsonProperty("data")
	public Data getData() {
		return data;
	}

	@JsonProperty("data")
	public void setData(Data data) {
		this.data = data;
	}

}