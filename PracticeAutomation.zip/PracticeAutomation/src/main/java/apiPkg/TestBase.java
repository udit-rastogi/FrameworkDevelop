package apiPkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import apiPkg.apiDefinitions.CreateCustomerApiDefinition;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class TestBase {

	public static Properties prop;
	static Logger logger;
	public static String configPath = System.getProperty("user.dir") + "\\src\\main\\resources\\Files";

	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_hhmmss");
		System.setProperty("current.date", dateFormat.format(new Date()));
	}

	public TestBase() {
		PropertyConfigurator.configure(configPath + "\\log4j.properties");
		logger = Logger.getLogger(TestBase.class.getName());
//		logger = Logger.getLogger(getClass());
//		BasicConfigurator.configure();
//		logger.info("This is my first log4j's statement");

		try {
			prop = new Properties();
			FileInputStream inputStream = new FileInputStream(configPath + "\\config.properties");
			prop.load(inputStream);

		} catch (FileNotFoundException Ex) {
			logger.info("File not found: " + Ex.getMessage());

		} catch (IOException Ex) {
			logger.info("Exception occurred: " + Ex.getMessage());
		}
	}

	public static RequestSpecification reqGeneric() {
		RequestSpecification reqSpec = null;
		reqSpec = RestAssured.given().headers(CreateCustomerApiDefinition.mainHeaders(prop.getProperty("token")));
		return reqSpec;
	}

}
