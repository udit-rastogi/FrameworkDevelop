package apiPkg.apiDefinitions;

import java.sql.Time;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import apiPkg.objects.CreateUserRequest;
import net.bytebuddy.utility.RandomString;

public class CreateCustomerApiDefinition {

	Date date = new Date();

	public static Map<String, String> mainHeaders(final String token) {
		return new HashMap<String, String>() {
			{
				put("Content-Type", "application/json");
				put("Accept", "application/json");
				put("Authorization", "Bearer " + token);
			}
		};
	}

	public static CreateUserRequest createRequest() {
		final CreateUserRequest createUserreq = new CreateUserRequest();
		createUserreq.setName("Tom Ryan");
		createUserreq.setStatus("Active");
		createUserreq.setGender("Male");
		createUserreq.setEmail("tom.ryan" + new Date().getTime() + "@hello.com");

		return createUserreq;
	}

}
